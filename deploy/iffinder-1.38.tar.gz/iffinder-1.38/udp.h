/*
 * Udp protocol header.
 * Per RFC 768, September, 1981.
 */
struct udphdr {
    unsigned short	uh_sport;		/* source port */
    unsigned short	uh_dport;		/* destination port */
    unsigned short	uh_ulen;		/* udp length */
    unsigned short	uh_sum;			/* udp checksum */
};
